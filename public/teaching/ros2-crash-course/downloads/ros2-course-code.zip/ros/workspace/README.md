# ROS 2 Jazzy reference workspace

Copy the four directories under src/ into ~/ros2_ws/src. Use Ubuntu 24.04’s system Python with Jazzy, then install declared dependencies with rosdep, build with colcon and source install/setup.bash.

## Core packages

ros2_course_interfaces generates the example message/service/action types. ros2_course_py contains the Python examples and phone_bridge. ros2_course_cpp contains the C++ counterparts. ros2_course_bringup is retained as a simple launch package; the old stereo launch is no longer the phone project’s entry point.

phone_bridge validates an authenticated native Android WSS session over wired USB or wireless before publishing Image, CompressedImage, CameraInfo and diagnostic Imu messages. Run with --cert/--key and optional --calibration; the course appendix explains trust, network and calibration setup. Its dependencies include aiohttp, OpenCV, numpy, yaml and cv_bridge.

## Optional mapping

The separate ros/slam/phone_orb_slam3 adapter is built in a different workspace after the external ORB-SLAM3 engine is compiled. The four beginner packages build independently of this adapter. The adapter maps from camera images; the native motion topics support inspection exercises. The monocular output is sparse and arbitrary-scale; see the backend README and phone setup appendix.

## Verification and licenses

The beginner packages are Apache-2.0; the optional adapter is GPL-3.0-or-later. The Android app is Apache-2.0. Legacy LiDAR helpers are optional simulation exercises with a separate learning purpose.
