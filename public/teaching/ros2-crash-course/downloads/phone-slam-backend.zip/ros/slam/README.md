# Optional monocular mapping adapter

phone_orb_slam3/ is a ROS package linked to an externally built ORB-SLAM3 engine. Keep it in a separate workspace from the four beginner packages. See its README, the course's Phone lab setup and calibration annexes.

The phone-slam-backend.zip release preserves ros/slam/phone_orb_slam3 and includes maintenance/tools/calibration_to_orb.py plus the preparation notes and illustrations. Commands in those notes run from the extracted bundle root. ORB-SLAM3, Pangolin and the vocabulary are separate instructor-prepared dependencies. The adapter has not been compiled or hardware-qualified on this authoring Windows host.
