# Optional monocular phone backend

This package links to the external upstream ORB-SLAM3 library; it is separate from the four beginner packages and uses GPL-3.0-or-later. No engine/vocabulary/binary is bundled. Read the course’s Phone lab setup appendix before building. This adapter has not been compiled on the authoring Windows host; qualify an exact Ubuntu 24.04/Jazzy/engine dependency combination before class.

1. Build a compatible Pangolin and ORB-SLAM3 following upstream requirements; record commits and patches. The engine README’s older tested environments are not a promise of a one-command Jazzy build.
2. Copy this package into ~/phone_slam_ws/src and build with `colcon build --cmake-args -DORB_SLAM3_ROOT=$HOME/ORB_SLAM3`. Source that workspace.
3. Calibrate the Android app’s exact transmitted stream with the ROS calibration tool and run the supplied calibration_to_orb.py converter. Use actual lens/resolution/distortion values; no example camera calibration is bundled.
4. Start the receiver and Android app over USB or wireless, then run phone_mono with vocabulary, settings and keyframe_output parameters shown in lecture 5.

Input: /phone/camera/image_raw, bgr8, calibrated dimensions and increasing stamped time. The adapter uses MONOCULAR mode; it leaves the accelerometer/gyroscope topics for inspection. The Pangolin viewer shows optimized sparse landmarks/keyframes. ROS camera_pose, current tracked_points and bounded path are diagnostic outputs, with arbitrary monocular scale under phone_slam_world. No metric TF is fabricated. The historic path is not retroactively optimized at loop closure.

On normal shutdown, SaveKeyFrameTrajectoryTUM exports keyframe poses; it is not a serialized dense map. Copy any output you want to preserve before reusing its filename. For replay, stop live input, start a fresh backend with use_sim_time true, then play the matching bag with --clock. Qualify actual sensor timestamps, initialization and map behavior with a real phone before distributing a classroom image.

The adapter targets the inspected public System/MapPoint APIs in upstream ORB-SLAM3 (Sophus poses, TrackMonocular, GetTrackingState, GetTrackedMapPoints, GetWorldPos). Record the engine revision actually used. Preserve upstream license and attribution if distributing a combined binary. This course adapter carries SPDX GPL-3.0-or-later; its license text is available from the upstream project and GNU.
