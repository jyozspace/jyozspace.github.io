# Nodes to Maps Android sensor

Small Java/Camera2 application for Android 8.0+ (API 26). It sends fixed-mode, unrotated camera JPEGs and independently timestamped accelerometer/gyroscope events to phone_bridge over pinned TLS WebSockets. Capture is foreground-only; Stop and onPause release the camera, sensor listeners, socket and screen-awake flag. Source license: Apache-2.0, supplied in LICENSE.

## Build

Open this directory in Android Studio with JDK 17 and Android SDK 35 installed, let the project sync, then build the debug APK. The Android Gradle plugin is 8.7.3; use Gradle 8.9 for command-line builds (`./gradlew :app:assembleDebug` on Linux/macOS or `./gradlew.bat :app:assembleDebug` on Windows). The checksum-pinned Gradle wrapper is included. The output is app/build/outputs/apk/debug/app-debug.apk.

On Windows, build-local.ps1 also compiles directly with an existing JDK 17, Android platform 35 and build tools 35.0.0. Pass their absolute directories using -Jdk, -Platform and -BuildTools. This script does not install tools or accept SDK licenses. It creates an ignored local classroom debug signing key. Keep that key if you want later APKs to update an installation with the same signer. Use your own protected release key for public releases. An APK rebuilt with a different signer requires uninstalling the existing classroom build before installation. The source archive excludes signing files and build dependencies.

## Pair

Build the updated ROS workspace and start phone_bridge with its TLS certificate and key. The terminal prints an Android endpoint, a fresh session token and the leaf certificate SHA-256. Enter those in the APK and tap Start. The exact certificate pin authenticates this receiver even when a development CA is not installed on Android. The implementation checks certificate validity and the exact leaf fingerprint; it does not modify global trust. A certificate replacement requires a new pin. Pairing values stay in memory and are excluded from Android state saving/backup.

The capstone has two connection options: wired USB or wireless. For wireless, use the laptop’s address on the phone hotspot. For USB run `adb reverse tcp:8443 tcp:8443` on the computer that can reach the receiver at its own localhost:8443, then use `wss://127.0.0.1:8443/ws/android`. The course WSL annex explains Windows ADB with ROS inside WSL 2. USB debugging is optional and can be revoked after the lab.

## Measurement contract

The chosen rear camera ID, YUV size <=640 pixels per edge, sensor orientation and timestamp source are displayed and sent as diagnostics. The image is converted from YUV to JPEG without rotation, mirroring or resizing. Both video and optical stabilization are requested off. Focus is continuous-video when supported; validate image geometry/focus on the chosen phone and recalibrate the exact stream. The preview shows those same decoded pixels.

When SENSOR_INFO_TIMESTAMP_SOURCE is REALTIME, Image timestamps share the elapsedRealtimeNanos base used by SensorEvent. For UNKNOWN devices this app explicitly uses an image callback estimate, while motion retains sensor event timestamps. A minimum-RTT handshake maps that phone clock to laptop ROS time. Network asymmetry/drift, exposure duration and rolling shutter remain relevant. The supplied mapper still uses MONOCULAR mode.

Accelerometer and gyroscope packets are independent: they retain their individual timestamps and units (m/s² and rad/s). The receiver publishes /phone/imu/accelerometer and /phone/imu/gyroscope, with the unavailable fields flagged through covariance[0] = -1. The frame is phone_android_device. A calibrated time-aware integration stage is needed before an estimator expecting combined IMU messages can consume them.

## Qualification

Compile/signature verification and transport tests are separate from device qualification. Test install, permission denial, valid/wrong pin, valid/wrong token, camera mode, sensor rates, Start/Stop, backgrounding, reconnect, clock metadata, camera calibration and a real mapping run before distributing this APK to a class. No emulator or physical phone validation is implied by a successful build.
