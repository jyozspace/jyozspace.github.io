# Build component notices

The Gradle 8.9 wrapper scripts/JAR are from the official gradle/gradle v8.9.0 repository and use Apache-2.0. Their original notices remain in the supplied files. Wrapper JAR SHA-256: 498495120a03b9a6ab5d155f5de3c8f0d986a449153702fb80fc80e134484f17, checked against services.gradle.org/distributions/gradle-8.9-wrapper.jar.sha256. The wrapper pins the Gradle distribution checksum in gradle-wrapper.properties.

The locally produced APK contains the original application classes and Android runtime references; it has no third-party runtime libraries. JDK, Android SDK/build tools and Gradle distributions are development dependencies and are not bundled in the app source or website archives. Their licenses are supplied by their vendors.
